function isFibo(n) {
  let a = 0;
  let b = 1;
  if ((a === 0)) return a;
  if ((b === 1)) return b;

  for (let i = 2; i <= n; i++) {
    temp = a + b;
    a = b;
    b = temp;
  }
}
